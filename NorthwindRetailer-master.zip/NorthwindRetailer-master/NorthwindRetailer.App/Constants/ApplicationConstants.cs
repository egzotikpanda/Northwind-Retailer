﻿using System.Configuration;

namespace NorthwindRetailer.App.Constants
{
    static class ApplicationConstants
    {
        private const string ConnectionStringName = "NorthwindDev";
        public static string ConnectionString
        {
            get => ConfigurationManager.ConnectionStrings[ConnectionStringName].ConnectionString;
        }
    }
}
