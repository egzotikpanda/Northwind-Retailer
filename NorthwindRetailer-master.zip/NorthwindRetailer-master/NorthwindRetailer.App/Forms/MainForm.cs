﻿using NorthwindRetailer.App.Constants;
using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace NorthwindRetailer.App.Forms
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();

            cbSelectAll.Checked = true;
            cbDiscontinued.Visible = false;

            txtMinPrice.KeyPress += TxtPrice_KeyPress;
            txtMaxPrice.KeyPress += TxtPrice_KeyPress;

            txtSearch.TextChanged += HandleSearch;
            txtMinPrice.TextChanged += HandleSearch;
            txtMaxPrice.TextChanged += HandleSearch;
            cbDiscontinued.CheckedChanged += HandleSearch;
            cbSelectAll.CheckedChanged += CbSelectAll_CheckedChanged;
        }

        private void CbSelectAll_CheckedChanged(object sender, EventArgs e)
        {
            cbDiscontinued.Visible = !cbSelectAll.Checked;
            FillProductsDGV();
        }

        private void HandleSearch(object sender, EventArgs e)
        {
            FillProductsDGV();
        }

        private void TxtPrice_KeyPress(object sender, KeyPressEventArgs e)
        {
            var textBox = (TextBox)sender;

            if (!char.IsDigit(e.KeyChar) && e.KeyChar != 8 && e.KeyChar != '.')
                e.Handled = true;

            if ((textBox.Text.Contains(".") || textBox.TextLength == 0) && e.KeyChar == '.')
                e.Handled = true;
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void newProductToolStripMenuItem_Click(object sender, EventArgs e)
        {
            new AddProductForm().ShowDialog();
        }

        private void MainForm_Load(object sender, EventArgs e)
        {
            dataGridView1.ReadOnly = true;
            dataGridView1.SelectionMode = DataGridViewSelectionMode.FullRowSelect;

            FillProductsDGV(); //Products DataGridView'ını doldur.
        }

        private void FillProductsDGV()
        {
            //'); DROP TABLE [Order Details]; --

            //search
            var selectCommandText = $"SELECT c.CategoryName, p.* FROM Products p JOIN Categories c ON c.CategoryID = p.CategoryID WHERE (p.ProductName LIKE @searchText OR c.CategoryName LIKE @searchText) ";

            //min price
            if (double.TryParse(txtMinPrice.Text, out double minPrice))
                selectCommandText += $"AND UnitPrice >= {minPrice} ";
            //max price
            if (double.TryParse(txtMaxPrice.Text, out double maxPrice))
                selectCommandText += $"AND UnitPrice <= {maxPrice} ";

            if (!cbSelectAll.Checked)
                selectCommandText += $"AND Discontinued = {(cbDiscontinued.Checked ? 1 : 0)} ";

            //var searchParameter = new SqlParameter("@searchText", "%" + txtSearch.Text + "%");
            var sqlCommand = new SqlCommand(selectCommandText, new SqlConnection(ApplicationConstants.ConnectionString));

            //sqlCommand.Parameters.Add(searchParameter);
            sqlCommand.Parameters.AddWithValue("@searchText", "%" + txtSearch.Text + "%");
            var adapter = new SqlDataAdapter(sqlCommand);

            var dataTable = new DataTable();
            adapter.Fill(dataTable);

            dataGridView1.DataSource = dataTable;
        }

    }
}
