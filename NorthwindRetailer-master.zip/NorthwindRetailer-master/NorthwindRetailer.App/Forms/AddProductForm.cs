﻿using NorthwindRetailer.App.Constants;
using NorthwindRetailer.App.Models;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace NorthwindRetailer.App.Forms
{
    public partial class AddProductForm : Form
    {
        public AddProductForm()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            InitializeControls();
        }

        private void InitializeControls()
        {
            cmbCategories.DropDownStyle = ComboBoxStyle.DropDownList;
            nudUnitPrice.DecimalPlaces = 2;
            nudUnitsInStock.DecimalPlaces = 0;
            nudUnitPrice.Maximum = nudUnitsInStock.Maximum = decimal.MaxValue;

            cmbCategories.DataSource = ReadCategories();

            cmbCategories.ValueMember = "Id";
            cmbCategories.DisplayMember = "Name";
        }

        private ICollection<Category> ReadCategories()
        {
            using (var connection = new SqlConnection(ApplicationConstants.ConnectionString)) //IDisposable
            {
                connection.Open();
                var selectCommandText = "SELECT CategoryID id, CategoryName FROM Categories";
                var selectCommand = new SqlCommand(selectCommandText, connection);

                var reader = selectCommand.ExecuteReader();
                ICollection<Category> categories = new List<Category>();

                while (reader.Read())
                {
                    var category = new Category
                    {
                        Id = Convert.ToInt32(reader[0]),
                        Name = reader["CategoryName"].ToString()
                    };

                    categories.Add(category);
                }

                return categories;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            var productName = txtProductName.Text;
            var categoryId = cmbCategories.SelectedValue.ToString();
            var unitPrice = nudUnitPrice.Value.ToString();
            var unitsInStock = nudUnitsInStock.Value.ToString();
            var discontinued = cbDiscontinued.Checked ? "1" : "0";

            var insertCommand = $"INSERT Products(ProductName, CategoryID, UnitPrice, UnitsInStock, Discontinued) VALUES ('{productName}', {categoryId}, {unitPrice}, {unitsInStock}, {discontinued})";

            using (var connection = new SqlConnection(ApplicationConstants.ConnectionString))
            {
                var command = new SqlCommand(insertCommand, connection);

                connection.Open();
                var affectedRows = command.ExecuteNonQuery();

                if (affectedRows > 0)
                    MessageBox.Show("Product added successfully");
            }
        }
    }
}
